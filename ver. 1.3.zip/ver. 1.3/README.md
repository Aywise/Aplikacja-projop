# Aplikacja-projop

Kalkulator ver.0.00

jest to prosty kalkulator(potem bedzie rozbudowywany)


# Interfejs

Kalkulator posiada interfejs uzytkownika, ktory umozliwia wprowadzenie danych wejsciowych i wyswietlenie wynikow obliczen.

Interfejs zawiera przyciski numeryczne, operacje matematyczne (dodawanie, odejmowanie, mnozenie, dzielenie).


# Jak dziala?

-Uzytkownik wprowadza dane korzystajac z klawiatury

-Wybiera operator matematyczny z dostepnych

-Kalkulator wykonuje obliczenia na podstawie wprowadzonych danych(js)

-Po zakonczeniu obliczen kalkulator wyswietla wynik na ekranie.


# Inne mechanizmy

Kalkulator moze zawierac mechanizmy obslugi bledow, ktore informuja uzytkownika o blednych danych wejsciowych (dzielenie przez zero)



# Ver 1.00

- Dodane potegowanie i pierwiastkowanie

- Optymalizacja kodu
   
   

# Ver 1.1

- Redesign aplikacji



# Ver 1.2

- Dodane menu ustawien

- Testowanie aplikacji(automatycznie)

# Ver 1.3

- debugowanie kodu(manualne)