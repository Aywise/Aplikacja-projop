function oblicz(operacja) {
  const a = parseFloat(document.getElementById('a').value);
  const b = parseFloat(document.getElementById('b').value);
  let wynik;

  switch (operacja) {
      case 'dodawanie':
          wynik = a + b;
          break;
      case 'odejmowanie':
          wynik = a - b;
          break;
      case 'mnozenie':
          wynik = a * b;
          break;
      case 'dzielenie':
          wynik = (b !== 0) ? a / b : 'ERROR';
          break;

  }

  document.getElementById('wynik').innerHTML = 'Wynik: ' + wynik;
}
function pierwiastek() {
    const a = parseFloat(document.getElementById('a').value);
    const wynik = Math.sqrt(a);
    document.getElementById('wynik').innerHTML = 'Wynik: ' + wynik;
}
function pierwiastek3() {
  const a = parseFloat(document.getElementById('a').value);
  let wynik = Math.pow(a, 1/3);
  document.getElementById('wynik').innerHTML = 'Wynik: ' + wynik;
}
function potega2() {
  const a = parseFloat(document.getElementById('a').value);
  let wynik = a ** 2;
  document.getElementById('wynik').innerHTML = 'Wynik: ' + wynik;
}
function potega3() {
  const a = parseFloat(document.getElementById('a').value);
  let wynik = a ** 3;
  document.getElementById('wynik').innerHTML = 'Wynik: ' + wynik;
}


document.addEventListener("DOMContentLoaded", function() {
  const settingsButton = document.querySelector('#settings');
  const sidebar = document.querySelector('#sidebar');

  settingsButton.addEventListener('click', function() {
      sidebar.classList.toggle('show-sidebar');
  });
});

document.addEventListener('DOMContentLoaded', function () {
    const sidebar = document.getElementById('sidebar');
    const settingsBtn = document.getElementById('settings');

    settingsBtn.addEventListener('click', function () {
        sidebar.classList.toggle('clicked');
        if (sidebar.classList.contains('clicked')) {
            sidebar.style.left = '0';
        } else {
            sidebar.style.left = '-250px';
        }
    });
});
const themeLight = document.getElementById('themeLight');
    const themeDark = document.getElementById('themeDark');
    const body = document.body;

    themeLight.addEventListener('click', () => {
        body.classList.remove('dark');
        body.classList.add('light');
    });

    themeDark.addEventListener('click', () => {
        body.classList.remove('light');
        body.classList.add('dark');
    });
