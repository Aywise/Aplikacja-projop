function dodawanie() {
    const a = parseFloat(document.getElementById('a').value); 
    const b = parseFloat(document.getElementById('b').value); 
    const wynik = a + b; 
    document.getElementById('wynik').innerHTML = 'Wynik: ' + wynik; 
}
  
function odejmowanie() {
    const a = parseFloat(document.getElementById('a').value); 
    const b = parseFloat(document.getElementById('b').value); 
    const wynik = a - b;
    document.getElementById('wynik').innerHTML = 'Wynik: ' + wynik;
}
  
function mnozenie() {
    const a = parseFloat(document.getElementById('a').value);
    const b = parseFloat(document.getElementById('b').value);
    const wynik = a * b;
    document.getElementById('wynik').innerHTML = 'Wynik: ' + wynik;
}
function dzielenie() {
    const a = parseFloat(document.getElementById('a').value);
    const b = parseFloat(document.getElementById('b').value); 
    if (b == 0) { 
      document.getElementById('wynik').innerHTML = 'ERROR'; 
    } else {
      const wynik = a / b;
      document.getElementById('wynik').innerHTML = 'Wynik: ' + wynik;
    }
  }
  